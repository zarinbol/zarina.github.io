<div class="grid-x" style="background-color: rgb(71, 28, 108);">
  <div class="cell">
  	<p class="text-center">
  		<h1 class="subheader text-center" style="color: white; font-size: 35px; font-family: Cantarell;">Mariel's Beauty Salon</h1>
		<h2 class="subheader text-center" style="color: white; font-family: Cantarell; font-size: 15px;">OZAMIS ST. LOWER LANGCANGAN OROQUIETA CITY</h2>
		<h3 class="subheader text-center" style="font-family: Cantarell; font-size: 13px; color: white;">WEBSITE CREATED BY JOEL T. AGOT</h3>
  	</p>
  </div>
</div>