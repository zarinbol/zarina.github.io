<div class="top-bar">
  <div class="top-bar-left">
    <ul class="dropdown menu" data-dropdown-menu>
      <li class="menu-text" style="font-family: Cantarell">Mariel's Beauty Salon</li>
      <li><a href="#">Contact Us</a></li>
      <li><a href="#">About Us</a></li>
    </ul>
  </div>
  <div class="top-bar-right">
      <a href="login.php" class="button hollow" type="button">Log In</a>
  </div>
</div>